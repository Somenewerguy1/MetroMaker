#MetroMaker

import os
import sys
import pygame
import tkinter as tk
from tkinter import filedialog





# ---------------------------
# Configuration / Defaults
# ---------------------------
WINDOW_TITLE = "MetroMaker"
SIDEBAR_WIDTH = 300
DEFAULT_GRID_W = 64
DEFAULT_GRID_H = 64
TILE_PIXEL = 16            # each tile's native pixel size (assets should be 16x16 ideally)
INITIAL_TILE_DISPLAY = 32  # thumbnail size in toolbar
GRID_OPACITY_DEFAULT = 0.60
FPS = 60
bg_color = (20, 20, 20)      # default tuple
ui_color = "#1c1c1c"         # can also be hex
grid_color = (80, 80, 80)


# Make folder paths absolute based on script location
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ASSETS_FOLDER = os.path.join(BASE_DIR, "assets")
FONTS_FOLDER = os.path.join(BASE_DIR, "fonts")
ICON_FOLDER = os.path.join(BASE_DIR, "windowIcon")
SETTINGS_FILE = os.path.join(BASE_DIR, "settings.json")

# ---------------------------
# Helper utilities
# ---------------------------

# Helper to keep RGB values in 0-255
def clamp(v, minv=0, maxv=255):
    return max(minv, min(v, maxv))


def hex_to_rgb(hex_str):
    if not hex_str:
        return None
    s = hex_str.strip().lstrip('#')
    if len(s) != 6:
        return None
    try:
        return tuple(int(s[i:i+2], 16) for i in (0,2,4))
    except ValueError:
        return None


def get_color(c):
    """
    Accepts either a hex string '#RRGGBB' or an (R,G,B) tuple.
    Returns an (R,G,B) tuple for Pygame.
    Uses default gray if input is invalid.
    """
    if isinstance(c, tuple) and len(c) in (3, 4):
        return c
    elif isinstance(c, str) and c.startswith('#'):
        # Convert hex to RGB
        h = c.lstrip('#')
        if len(h) == 6:
            return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))
    print(f"WARNING: invalid color {c}, using default gray")
    return (128, 128, 128)

# ---------------------------
# Start tkinter for file dialogs
# ---------------------------

# ---------------------------
# Settings persistence
# ---------------------------
import json
SETTINGS_FILE = "settings.json"




def default_settings():
    return {
        "bg_color": '#141414',
        "ui_color": '#1c1c1c',
        "grid_color": '#505050',
        "grid_opacity": GRID_OPACITY_DEFAULT if 'GRID_OPACITY_DEFAULT' in globals() else 0.6,
        "grid_w": DEFAULT_GRID_W,
        "grid_h": DEFAULT_GRID_H,
        "selected_font_index": selected_font_index if 'selected_font_index' in globals() else -1
    }


def save_settings():
    global bg_color, ui_color, grid_color, grid_opacity, grid_w, grid_h, selected_font_index
    try:
        s = {
            "bg_color": '#%02x%02x%02x' % tuple(bg_color) if isinstance(bg_color, tuple) else (bg_color or '#141414'),
            "ui_color": '#%02x%02x%02x' % tuple(ui_color) if isinstance(ui_color, tuple) else (ui_color or '#1c1c1c'),
            "grid_color": '#%02x%02x%02x' % tuple(grid_color) if isinstance(grid_color, tuple) else (grid_color or '#505050'),
            "grid_opacity": float(grid_opacity) if 'grid_opacity' in globals() else 0.6,
            "grid_w": int(grid_w) if 'grid_w' in globals() else 16,
            "grid_h": int(grid_h) if 'grid_h' in globals() else 16,
            "selected_font_index": int(selected_font_index) if 'selected_font_index' in globals() else -1
        }
        with open(SETTINGS_FILE, 'w') as f:
            json.dump(s, f, indent=2)
        print('Settings saved to', SETTINGS_FILE)
    except Exception as e:
        print('Failed to save settings:', e)


def load_settings():
    global bg_color, ui_color, grid_color, grid_opacity, grid_w, grid_h, grid, selected_font_index, UI_FONT, UI_FONT_SMALL, UI_FONT_TITLE
    if not os.path.exists(SETTINGS_FILE):
        # create default settings
        try:
            with open(SETTINGS_FILE, 'w') as f:
                json.dump(default_settings(), f, indent=2)
            print('Created default settings file')
        except Exception as e:
            print('Failed to create settings file:', e)
        return

    try:
        with open(SETTINGS_FILE, 'r') as f:
            s = json.load(f)

        def safe_hex_to_rgb(hex_str, fallback):
            try:
                return hex_to_rgb(hex_str) or fallback
            except Exception:
                return fallback

        bg_color = safe_hex_to_rgb(s.get('bg_color'), (20, 20, 20))
        ui_color = safe_hex_to_rgb(s.get('ui_color'), (28, 28, 28))
        grid_color = safe_hex_to_rgb(s.get('grid_color'), (80, 80, 80))
        grid_opacity = float(s.get('grid_opacity', 0.6))
        grid_w = max(1, int(s.get('grid_w', 16)))
        grid_h = max(1, int(s.get('grid_h', 16)))

        # initialize grid safely
        grid = [[None for _ in range(grid_h)] for _ in range(grid_w)]

        sfi = int(s.get('selected_font_index', -1))
        if 0 <= sfi < len(available_font_files):
            selected_font_index = sfi
            try:
                UI_FONT = pygame.font.Font(available_font_files[selected_font_index], 16)
                UI_FONT_SMALL = pygame.font.Font(available_font_files[selected_font_index], 14)
                UI_FONT_TITLE = pygame.font.Font(available_font_files[selected_font_index], 18)
            except Exception:
                print('Failed to load selected font, using default.')

        print('Settings loaded from', SETTINGS_FILE)

    except Exception as e:
        print('Failed to load settings:', e)

# Absolute paths
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SETTINGS_FILE = os.path.join(BASE_DIR, "settings.json")

# Load settings immediately
load_settings()

# ---------------------------
root_tk = tk.Tk()
root_tk.withdraw()

# ---------------------------
# Initialize pygame
# ---------------------------
pygame.init()
pygame.display.set_caption(WINDOW_TITLE)
info = pygame.display.Info()
# Start window slightly smaller than full screen so taskbar is visible
START_W = int(info.current_w * 0.92)
START_H = int(info.current_h * 0.88)
screen = pygame.display.set_mode((START_W, START_H), pygame.RESIZABLE)

# Window icon (optional)
if os.path.isdir(ICON_FOLDER):
    for f in os.listdir(ICON_FOLDER):
        if f.lower().endswith('.png'):
            try:
                icon_surf = pygame.image.load(os.path.join(ICON_FOLDER, f))
                pygame.display.set_icon(icon_surf)
            except Exception:
                pass
            break

clock = pygame.time.Clock()

# ---------------------------
# Font loading (global UI font)
# ---------------------------
def find_font_file():
    if not os.path.isdir(FONTS_FOLDER):
        return None
    for f in sorted(os.listdir(FONTS_FOLDER)):
        if f.lower().endswith(('.ttf', '.otf')):
            return os.path.join(FONTS_FOLDER, f)
    return None

font_file = find_font_file()
if font_file:
    try:
        UI_FONT = pygame.font.Font(font_file, 16)
        UI_FONT_SMALL = pygame.font.Font(font_file, 14)
        UI_FONT_TITLE = pygame.font.Font(font_file, 18)
    except Exception:
        UI_FONT = pygame.font.SysFont('Courier', 16)
        UI_FONT_SMALL = pygame.font.SysFont('Courier', 14)
        UI_FONT_TITLE = pygame.font.SysFont('Courier', 18)
else:
    UI_FONT = pygame.font.SysFont('Courier', 16)
    UI_FONT_SMALL = pygame.font.SysFont('Courier', 14)
    UI_FONT_TITLE = pygame.font.SysFont('Courier', 18)

# Keep track of available fonts too
available_font_files = []
if os.path.isdir(FONTS_FOLDER):
    for f in sorted(os.listdir(FONTS_FOLDER)):
        if f.lower().endswith(('.ttf', '.otf')):
            available_font_files.append(os.path.join(FONTS_FOLDER, f))


# ---------------------------
# Load assets (all pngs in assets folder)
# Each asset stored as original surface and scaled preview
# ---------------------------
assets = []       # list of surfaces at TILE_PIXEL size
asset_names = []
if os.path.isdir(ASSETS_FOLDER):
    for fname in sorted(os.listdir(ASSETS_FOLDER)):
        if fname.lower().endswith('.png'):
            try:
                img = pygame.image.load(os.path.join(ASSETS_FOLDER, fname)).convert_alpha()
                # scale to tile pixel size
                img = pygame.transform.scale(img, (TILE_PIXEL, TILE_PIXEL))
                assets.append(img)
                asset_names.append(fname)
            except Exception:
                pass

# Add eraser tool as an explicit tool (None) appended as last asset
assets.append(None)
asset_names.append('Eraser')

# ---------------------------
# Preset colors
# ---------------------------
PRESET_COLORS = {
    'Black': (20,20,20),
    'Grey': (128,128,128),
    'White': (230,230,230),
    'Red': (200,50,50),
    'Green': (50,200,50),
    'Blue': (50,50,200),
    'Yellow': (200,200,50),
    'Cyan': (50,200,200),
    'Magenta': (200,50,200),
}

# ---------------------------
# Editor State
# ---------------------------
selected_asset = 0
# grid dimensions in tiles
grid_w = DEFAULT_GRID_W = DEFAULT_GRID_W = DEFAULT_GRID_W if 'DEFAULT_GRID_W' in globals() else 64
grid_h = DEFAULT_GRID_H = DEFAULT_GRID_H if 'DEFAULT_GRID_H' in globals() else 64
# initialize grid (2D list of None or surface indices)
grid = [[None for _ in range(grid_h)] for _ in range(grid_w)]

# canvas transform
canvas_offset_x = 0.0
canvas_offset_y = 0.0
zoom = 1.0

# colors
bg_color = PRESET_COLORS['Black']
ui_color = (28,28,28)
grid_color = (80,80,80)
grid_opacity = GRID_OPACITY_DEFAULT if 'GRID_OPACITY_DEFAULT' in globals() else 0.60

# toolbar scroll
toolbar_scroll = 0

# text inputs
hex_bg_input = ''
hex_grid_input = ''
hex_ui_input = ''
hex_bg_active = False
hex_grid_active = False
hex_ui_active = False

# grid size text inputs
grid_w_input = str(grid_w)
grid_h_input = str(grid_h)
grid_w_active = False
grid_h_active = False

# slider state
slider_dragging = False

# modal
modal_active = False
modal_message = ''
modal_actions = {}  # {'Proceed': func, 'Cancel': func}

# mouse state
left_down = False
right_down = False
middle_down = False
panning = False
last_pan_pos = (0,0)

# font selection index
selected_font_index = 0 if available_font_files else -1

# Save button feedback timer (frames)
SAVE_FEEDBACK_DURATION = FPS  # duration in frames (1 second)
save_feedback_timer = 0

# load settings now that defaults and globals exist
load_settings()

# Hover visuals
HOVER_ALPHA = 80  # 0..255 for hover overlay transparency



# ---------------------------
# Helper drawing functions
# ---------------------------
def draw_text(surface, text, pos, font=None, color=(220,220,220)):
    if font is None:
        font = UI_FONT
    surface.blit(font.render(text, True, color), pos)

# compute visible tile range (for performance)
def visible_range(screen_w, screen_h):
    start_x = max(0, int((-canvas_offset_x) // (TILE_PIXEL*zoom)))
    start_y = max(0, int((-canvas_offset_y) // (TILE_PIXEL*zoom)))
    end_x = min(grid_w, int((screen_w - SIDEBAR_WIDTH - canvas_offset_x) // (TILE_PIXEL*zoom)) + 2)
    end_y = min(grid_h, int((screen_h - canvas_offset_y) // (TILE_PIXEL*zoom)) + 2)
    return start_x, start_y, end_x, end_y

# ---------------------------
# Toolbar clickable rects builder
# ---------------------------
def build_toolbar_layout(screen_w, screen_h):
    toolbar_x = screen_w - SIDEBAR_WIDTH
    y = 12 - toolbar_scroll
    left = toolbar_x + 12

    layout = {}
    layout['asset_rects'] = []

    # Assets area
    y += 28
    for i, surf in enumerate(assets):
        r = pygame.Rect(left, y, INITIAL_TILE_DISPLAY, INITIAL_TILE_DISPLAY)
        layout['asset_rects'].append((i, r))
        y += INITIAL_TILE_DISPLAY + 10

    y += 10
    # Background Colors title position
    layout['bg_title_y'] = y
    y += 28

    # Preset BG colors (store rects)
    layout['bg_color_rects'] = {}
    for name, rgb in PRESET_COLORS.items():
        r = pygame.Rect(left, y, 20, 20)
        layout['bg_color_rects'][name] = r
        y += 26

    y += 8
    # hex input BG
    layout['hex_bg_rect'] = pygame.Rect(left, y, SIDEBAR_WIDTH - (left - toolbar_x) - 20, 26)
    y += 36

    # Grid Settings title position
    layout['grid_title_y'] = y
    y += 28

    # Grid color presets
    layout['grid_color_rects'] = {}
    for name, rgb in PRESET_COLORS.items():
        r = pygame.Rect(left, y, 20, 20)
        layout['grid_color_rects'][name] = r
        y += 26

    y += 8
    layout['grid_opacity_slider'] = pygame.Rect(left, y, SIDEBAR_WIDTH - (left - toolbar_x) - 40, 10)
    y += 20
    layout['hex_grid_rect'] = pygame.Rect(left, y, SIDEBAR_WIDTH - (left - toolbar_x) - 20, 26)
    y += 36

    # grid size input
    box_w = (SIDEBAR_WIDTH - (left - toolbar_x) - 40) // 2
    layout['grid_w_rect'] = pygame.Rect(left, y, box_w, 28)
    layout['grid_h_rect'] = pygame.Rect(left + box_w + 20, y, box_w, 28)
    y += 36
    layout['apply_grid_rect'] = pygame.Rect(left, y, SIDEBAR_WIDTH - (left - toolbar_x) - 20, 36)
    y += 44

    # UI title position
    layout['ui_title_y'] = y
    y += 28

    # UI color presets
    layout['ui_color_rects'] = {}
    for name, rgb in PRESET_COLORS.items():
        r = pygame.Rect(left, y, 20, 20)
        layout['ui_color_rects'][name] = r
        y += 26

    y += 8
    layout['hex_ui_rect'] = pygame.Rect(left, y, SIDEBAR_WIDTH - (left - toolbar_x) - 20, 26)
    y += 36

    # Fonts list
    layout['font_rects'] = []
    layout['fonts_title_y'] = y
    y += 28
    for idx, fp in enumerate(available_font_files):
        r = pygame.Rect(left, y, SIDEBAR_WIDTH - (left - toolbar_x) - 20, 24)
        layout['font_rects'].append((idx, r))
        y += 28

    # Save settings button
    layout['save_settings_rect'] = pygame.Rect(left, y+10, SIDEBAR_WIDTH - (left - toolbar_x) - 20, 36)
    y += 48
    # Export button
    layout['export_rect'] = pygame.Rect(left, y+10, SIDEBAR_WIDTH - (left - toolbar_x) - 20, 36)

    return layout

# ---------------------------
# Draw toolbar UI
# ---------------------------
def draw_toolbar(surface, layout, screen_w, screen_h):
    toolbar_x = screen_w - SIDEBAR_WIDTH
    # background
    pygame.draw.rect(surface, get_color(ui_color), (toolbar_x, 0, SIDEBAR_WIDTH, screen_h))

    left = toolbar_x + 12

    # mouse pos for hover effects
    mx, my = pygame.mouse.get_pos()

    # Assets title (fixed position)
    draw_text(surface, 'Assets', (left, 12 - toolbar_scroll), UI_FONT_TITLE)

    # Draw asset previews with hover highlight
    for i, r in layout['asset_rects']:
        surf = assets[i]
        hovered = r.collidepoint(mx, my)
        # subtle drop shadow
        shadow = pygame.Rect(r.x+2, r.y+2, r.w, r.h)
        s = pygame.Surface((shadow.w, shadow.h), pygame.SRCALPHA)
        s.fill((0,0,0,40))
        surface.blit(s, shadow.topleft)

        if surf is None:
            eraser_box = pygame.Surface((r.w, r.h))
            eraser_box.fill((80,80,80))
            pygame.draw.line(eraser_box, (230,230,230), (4,4),(r.w-4,r.h-4),2)
            pygame.draw.line(eraser_box, (230,230,230), (r.w-4,4),(4,r.h-4),2)
            surface.blit(eraser_box, r.topleft)
        else:
            img = pygame.transform.scale(surf, (r.w, r.h))
            surface.blit(img, r.topleft)

        if i == selected_asset:
            pygame.draw.rect(surface, (240,200,60), r, 2)
        if hovered:
            hover_s = pygame.Surface((r.w, r.h), pygame.SRCALPHA)
            hover_s.fill((255,255,255,HOVER_ALPHA))
            surface.blit(hover_s, r.topleft)

        nm = asset_names[i] if i < len(asset_names) else 'Eraser'
        draw_text(surface, nm, (r.x + r.w + 6, r.y + (r.h - UI_FONT_SMALL.get_height())//2), UI_FONT_SMALL)

    # Background Colors title and swatches using layout positions
    draw_text(surface, 'Background Colors', (left, layout['bg_title_y']), UI_FONT_TITLE)
    for name, r in layout['bg_color_rects'].items():
        hovered = r.collidepoint(mx, my)
        pygame.draw.rect(surface, get_color(PRESET_COLORS[name]), r)
        pygame.draw.rect(surface, (200,200,200), r, 1)
        if hovered:
            hover_s = pygame.Surface((r.w, r.h), pygame.SRCALPHA)
            hover_s.fill((255,255,255,HOVER_ALPHA))
            surface.blit(hover_s, r.topleft)
        draw_text(surface, name, (r.x + r.w + 8, r.y), UI_FONT_SMALL)

    # Hex BG input
    hb = layout['hex_bg_rect']
    pygame.draw.rect(surface, (40,40,40), hb, border_radius=6)
    pygame.draw.rect(surface, (200,200,200), hb, 2 if hex_bg_active else 1, border_radius=6)
    draw_text(surface, hex_bg_input or '#RRGGBB', (hb.x+8, hb.y+4), UI_FONT_SMALL, color=(180,180,180))

    # Grid Settings title and controls
    draw_text(surface, 'Grid Settings', (left, layout['grid_title_y']), UI_FONT_TITLE)
    for name, r in layout['grid_color_rects'].items():
        hovered = r.collidepoint(mx, my)
        pygame.draw.rect(surface, get_color(PRESET_COLORS[name]), r)
        pygame.draw.rect(surface, (200,200,200), r, 1)
        if hovered:
            hover_s = pygame.Surface((r.w, r.h), pygame.SRCALPHA)
            hover_s.fill((255,255,255,HOVER_ALPHA))
            surface.blit(hover_s, r.topleft)
        draw_text(surface, name, (r.x + r.w + 8, r.y), UI_FONT_SMALL)

    slider = layout['grid_opacity_slider']
    pygame.draw.rect(surface, (60,60,60), slider, border_radius=4)
    filled = int(clamp(grid_opacity,0,1) * slider.w)
    if filled>0:
        pygame.draw.rect(surface, (140,140,140), (slider.x, slider.y, filled, slider.h), border_radius=4)
    pygame.draw.rect(surface, (200,200,200), slider, 1, border_radius=4)
    knob_x = slider.x + filled
    knob = pygame.Rect(knob_x-6, slider.y-6, 12, slider.h+12)
    pygame.draw.rect(surface, (220,220,220), knob, border_radius=6)

    hg = layout['hex_grid_rect']
    pygame.draw.rect(surface, (40,40,40), hg, border_radius=6)
    pygame.draw.rect(surface, (200,200,200), hg, 2 if hex_grid_active else 1, border_radius=6)
    draw_text(surface, hex_grid_input or '#RRGGBB', (hg.x+8, hg.y+4), UI_FONT_SMALL, color=(180,180,180))

    gw = layout['grid_w_rect']; gh = layout['grid_h_rect']
    pygame.draw.rect(surface, (40,40,40), gw, border_radius=6)
    pygame.draw.rect(surface, (200,200,200), gw, 2 if grid_w_active else 1, border_radius=6)
    pygame.draw.rect(surface, (40,40,40), gh, border_radius=6)
    pygame.draw.rect(surface, (200,200,200), gh, 2 if grid_h_active else 1, border_radius=6)
    draw_text(surface, grid_w_input, (gw.x+8, gw.y+4), UI_FONT_SMALL)
    draw_text(surface, grid_h_input, (gh.x+8, gh.y+4), UI_FONT_SMALL)

    ab = layout['apply_grid_rect']
    pygame.draw.rect(surface, (70,70,90), ab, border_radius=8)
    pygame.draw.rect(surface, (200,200,220), ab, 1, border_radius=8)
    draw_text(surface, 'Apply Grid Size (resets)', (ab.x+8, ab.y+6), UI_FONT)

    # UI Colors title and swatches
    draw_text(surface, 'UI Colors', (left, layout['ui_title_y']), UI_FONT_TITLE)
    for name, r in layout['ui_color_rects'].items():
        hovered = r.collidepoint(mx, my)
        pygame.draw.rect(surface, get_color(PRESET_COLORS[name]), r)
        pygame.draw.rect(surface, (200,200,200), r, 1)
        if hovered:
            hover_s = pygame.Surface((r.w, r.h), pygame.SRCALPHA)
            hover_s.fill((255,255,255,HOVER_ALPHA))
            surface.blit(hover_s, r.topleft)
        draw_text(surface, name, (r.x + r.w + 8, r.y), UI_FONT_SMALL)

    hu = layout['hex_ui_rect']
    pygame.draw.rect(surface, (40,40,40), hu, border_radius=6)
    pygame.draw.rect(surface, (200,200,200), hu, 2 if hex_ui_active else 1, border_radius=6)
    draw_text(surface, hex_ui_input or '#RRGGBB', (hu.x+8, hu.y+4), UI_FONT_SMALL, color=(180,180,180))

    # Fonts title and list
    draw_text(surface, 'Fonts', (left, layout['fonts_title_y']), UI_FONT_TITLE)
    for idx, r in layout['font_rects']:
        hovered = r.collidepoint(mx, my)
        pygame.draw.rect(surface, (45,45,45), r, border_radius=6)
        if idx == selected_font_index:
            pygame.draw.rect(surface, (230,200,80), r, 2, border_radius=6)
        if hovered:
            hover_s = pygame.Surface((r.w, r.h), pygame.SRCALPHA)
            hover_s.fill((255,255,255,HOVER_ALPHA))
            surface.blit(hover_s, r.topleft)
        fname = os.path.basename(available_font_files[idx]) if idx < len(available_font_files) else 'N/A'
        draw_text(surface, fname, (r.x+6, r.y+4), UI_FONT_SMALL)
  # Save settings button
    sb = layout['save_settings_rect']

    if save_feedback_timer > 0:
        pulse = int((save_feedback_timer / SAVE_FEEDBACK_DURATION) * 80)
        color = (max(0, 40 - pulse), max(0, 40 - pulse), max(0, 100 - pulse))
        pygame.draw.rect(surface, color, sb, border_radius=8)
        pygame.draw.rect(surface, (200,200,220), sb, 1, border_radius=8)
        draw_text(surface, 'Saved :D', (sb.x+8, sb.y+6), UI_FONT, color=(200,255,200))
    else:
        pygame.draw.rect(surface, (60,60,100), sb, border_radius=8)
        pygame.draw.rect(surface, (200,200,220), sb, 1, border_radius=8)
        draw_text(surface, 'Save Settings', (sb.x+8, sb.y+6), UI_FONT)

    # Export button
    eb = layout['export_rect']
    pygame.draw.rect(surface, (70,90,70), eb, border_radius=8)
    pygame.draw.rect(surface, (200,220,200), eb, 1, border_radius=8)
    draw_text(surface, 'Export (PNG/JPEG)', (eb.x+8, eb.y+6), UI_FONT)

    # Return all interactive rects at the very end
    return {
        'knob_rect': knob,
        'slider_rect': slider,
        'save_button_rect': sb,
        'export_button_rect': eb
    }




# ---------------------------
# Modal dialog (in-pygame)
# ---------------------------
def open_modal(message, on_proceed, on_cancel):
    global modal_active, modal_message, modal_actions
    modal_active = True
    modal_message = message
    modal_actions = {'Proceed': on_proceed, 'Cancel': on_cancel}

# ---------------------------
# Export helper
# ---------------------------
def export_map_dialog(grid_w_local, grid_h_local):
    # build export surface of exact tile size
    if not any(any(cell is not None for cell in col) for col in grid):
        # empty map -> export simple one tile
        ew, eh = 1, 1
    else:
        maxx = max((x for x in range(grid_w_local) if any(grid[x][y] is not None for y in range(grid_h_local))), default=0)
        maxy = max((y for y in range(grid_h_local) if any(grid[x][y] is not None for x in range(grid_w_local))), default=0)
        ew, eh = maxx+1, maxy+1
    surf = pygame.Surface((ew*TILE_PIXEL, eh*TILE_PIXEL), pygame.SRCALPHA)
    surf.fill(bg_color)
    for x in range(ew):
        for y in range(eh):
            if grid[x][y] is not None:
                idx = grid[x][y]
                tile_surf = assets[idx]
                if tile_surf:
                    surf.blit(tile_surf, (x*TILE_PIXEL, y*TILE_PIXEL))
    # ask user for filename
    path = filedialog.asksaveasfilename(defaultextension='.png', filetypes=[('PNG', '*.png'), ('JPEG', '*.jpg;*.jpeg')])
    if path:
        try:
            pygame.image.save(surf, path)
            print('Saved', path)
        except Exception as e:
            print('Export failed:', e)

# ---------------------------
# Main loop
# ---------------------------
running = True
while running:
    screen_w, screen_h = screen.get_size()
    screen.fill(bg_color)

    # Draw grid content (tiles)
    sx, sy, ex, ey = visible_range(screen_w, screen_h)
    for gx in range(sx, ex):
        for gy in range(sy, ey):
            idx = grid[gx][gy]
            if idx is not None:
                tile = assets[idx]
                if tile is not None:
                    # scaled draw according to zoom
                    dest = pygame.Rect(canvas_offset_x + gx*TILE_PIXEL*zoom, canvas_offset_y + gy*TILE_PIXEL*zoom,
                                       int(TILE_PIXEL*zoom), int(TILE_PIXEL*zoom))
                    screen.blit(pygame.transform.scale(tile, (dest.w, dest.h)), dest.topleft)

    # Draw grid lines with opacity
    grid_surf = pygame.Surface((screen_w - SIDEBAR_WIDTH, screen_h), pygame.SRCALPHA)
    alpha = int(clamp(grid_opacity,0,1) * 255)
    line_color = (*grid_color, alpha)
    # vertical lines
    for gx in range(sx, ex+1):
        px = int(canvas_offset_x + gx*TILE_PIXEL*zoom)
        pygame.draw.line(grid_surf, line_color, (px,0), (px, screen_h))
    for gy in range(sy, ey+1):
        py = int(canvas_offset_y + gy*TILE_PIXEL*zoom)
        pygame.draw.line(grid_surf, line_color, (0,py), (screen_w - SIDEBAR_WIDTH, py))
    screen.blit(grid_surf, (0,0))

    # Build toolbar layout and draw
    layout = build_toolbar_layout(screen_w, screen_h)
    widget_draw_info = draw_toolbar(screen, layout, screen_w, screen_h)
    knob_rect = widget_draw_info['knob_rect']
    slider_rect = widget_draw_info['slider_rect']

    # Modal draw
    if modal_active:
        overlay = pygame.Surface((screen_w, screen_h), pygame.SRCALPHA)
        overlay.fill((0,0,0,150))
        screen.blit(overlay, (0,0))
        mw, mh = 520, 160
        mx = (screen_w - mw)//2
        my = (screen_h - mh)//2
        panel = pygame.Rect(mx,my,mw,mh)
        pygame.draw.rect(screen, (34,34,48), panel, border_radius=12)
        pygame.draw.rect(screen, (200,200,220), panel, 2, border_radius=12)
        # message
        draw_text(screen, modal_message, (mx+20, my+24), UI_FONT)
        # buttons
        btn_w, btn_h = 120, 36
        proceed_rect = pygame.Rect(mx + mw - btn_w - 20, my + mh - btn_h - 16, btn_w, btn_h)
        cancel_rect = pygame.Rect(proceed_rect.x - btn_w - 12, proceed_rect.y, btn_w, btn_h)
        pygame.draw.rect(screen, (80,100,80), proceed_rect, border_radius=10)
        pygame.draw.rect(screen, (100,80,80), cancel_rect, border_radius=10)
        draw_text(screen, 'Proceed', (proceed_rect.x+18, proceed_rect.y+8), UI_FONT)
        draw_text(screen, 'Cancel', (cancel_rect.x+28, cancel_rect.y+8), UI_FONT)

    pygame.display.flip()

    # Feedback timers
    if save_feedback_timer > 0:
        save_feedback_timer -= 1

    # Events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        elif event.type == pygame.VIDEORESIZE:
            new_w = max(640, event.w)
            new_h = max(480, event.h)
            screen = pygame.display.set_mode((new_w, new_h), pygame.RESIZABLE)

        # Modal interactions
        if modal_active:
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                mx, my = pygame.mouse.get_pos()
                if cancel_rect.collidepoint(mx,my):
                    modal_active = False
                    if 'Cancel' in modal_actions and callable(modal_actions['Cancel']):
                        modal_actions['Cancel']()
                    modal_actions = {}
                elif proceed_rect.collidepoint(mx,my):
                    modal_active = False
                    if 'Proceed' in modal_actions and callable(modal_actions['Proceed']):
                        modal_actions['Proceed']()
                    modal_actions = {}
            continue

        if event.type == pygame.MOUSEBUTTONDOWN:
            mx, my = pygame.mouse.get_pos()
            # toolbar area check - only respond to left-clicks in toolbar to avoid wheel/select issues
            if mx >= screen.get_width() - SIDEBAR_WIDTH and event.button == 1:
                # asset clicks (left click only)
                for i, r in layout['asset_rects']:
                    if r.collidepoint(mx, my):
                        selected_asset = i
                        left_down = False
                        break
                # bg presets
                for name, r in layout['bg_color_rects'].items():
                    if r.collidepoint(mx, my):
                        bg_color = PRESET_COLORS[name]
                        break
                # hex bg box
                if layout['hex_bg_rect'].collidepoint(mx, my):
                    hex_bg_active = True
                    hex_grid_active = hex_ui_active = False
                    grid_w_active = grid_h_active = False
                # grid color presets
                for name, r in layout['grid_color_rects'].items():
                    if r.collidepoint(mx, my):
                        grid_color = PRESET_COLORS[name]
                        break
                # slider (start drag)
                if widget_draw_info['slider_rect'].collidepoint(mx, my):
                    slider_dragging = True
                    rel = clamp((mx - widget_draw_info['slider_rect'].x) / widget_draw_info['slider_rect'].w, 0.0, 1.0)
                    grid_opacity = rel
                # hex grid box
                if layout['hex_grid_rect'].collidepoint(mx, my):
                    hex_grid_active = True
                    hex_bg_active = hex_ui_active = False
                    grid_w_active = grid_h_active = False
                # grid size boxes
                if layout['grid_w_rect'].collidepoint(mx, my):
                    grid_w_active, grid_h_active = True, False
                elif layout['grid_h_rect'].collidepoint(mx, my):
                    grid_w_active, grid_h_active = False, True
                # apply grid button
                if layout['apply_grid_rect'].collidepoint(mx, my):
                    if grid_w_input.isdigit() and grid_h_input.isdigit():
                        new_w = max(1, int(grid_w_input))
                        new_h = max(1, int(grid_h_input))
                        def do_apply():
                            global grid_w, grid_h, grid, canvas_offset_x, canvas_offset_y, zoom, grid_w_input, grid_h_input
                            grid_w, grid_h = new_w, new_h
                            grid = [[None for _ in range(grid_h)] for _ in range(grid_w)]
                            canvas_offset_x = 0.0; canvas_offset_y = 0.0; zoom = 1.0
                            grid_w_input = str(grid_w); grid_h_input = str(grid_h)
                        open_modal('Change grid size? This will erase the current drawing.', do_apply, lambda: None)
                # ui color presets
                for name, r in layout['ui_color_rects'].items():
                    if r.collidepoint(mx, my):
                        ui_color = PRESET_COLORS[name]
                        break
                # hex ui box
                if layout['hex_ui_rect'].collidepoint(mx, my):
                    hex_ui_active = True
                    hex_bg_active = hex_grid_active = False
                    grid_w_active = grid_h_active = False
                # fonts selection
                for idx, r in layout['font_rects']:
                    if r.collidepoint(mx, my):
                        selected_font_index = idx
                        try:
                            UI_FONT = pygame.font.Font(available_font_files[selected_font_index], 16)
                            UI_FONT_SMALL = pygame.font.Font(available_font_files[selected_font_index], 14)
                            UI_FONT_TITLE = pygame.font.Font(available_font_files[selected_font_index], 18)
                        except Exception:
                            pass
                # export button
                # save settings and export buttons
                if layout['save_settings_rect'].collidepoint(mx, my):
                    save_settings()
                    save_feedback_timer = SAVE_FEEDBACK_DURATION
                elif layout['export_rect'].collidepoint(mx, my):
                    export_map_dialog(grid_w, grid_h) 

            else:
                # clicked in canvas area — respond to mouse button types
                if event.button == 1:
                    left_down = True
                    gx = int((mx - canvas_offset_x) // (TILE_PIXEL * zoom))
                    gy = int((my - canvas_offset_y) // (TILE_PIXEL * zoom))
                    if 0 <= gx < grid_w and 0 <= gy < grid_h:
                        if selected_asset == len(assets)-1:
                            grid[gx][gy] = None
                        else:
                            grid[gx][gy] = selected_asset
                elif event.button == 3:
                    right_down = True
                    gx = int((mx - canvas_offset_x) // (TILE_PIXEL * zoom))
                    gy = int((my - canvas_offset_y) // (TILE_PIXEL * zoom))
                    if 0 <= gx < grid_w and 0 <= gy < grid_h:
                        grid[gx][gy] = None
                elif event.button == 2:
                    middle_down = True
                    panning = True
                    last_pan_pos = event.pos

        elif event.type == pygame.MOUSEBUTTONUP:
            if event.button == 1:
                left_down = False
            elif event.button == 3:
                right_down = False
            elif event.button == 2:
                middle_down = False; panning = False
            slider_dragging = False

        elif event.type == pygame.MOUSEMOTION:
            mx,my = event.pos
            if panning and middle_down:
                dx, dy = mx - last_pan_pos[0], my - last_pan_pos[1]
                canvas_offset_x += dx; canvas_offset_y += dy
                last_pan_pos = (mx,my)
            if slider_dragging:
                rel = clamp((mx - widget_draw_info['slider_rect'].x)/widget_draw_info['slider_rect'].w, 0.0, 1.0)
                grid_opacity = rel
            # drag painting/erasing
            if left_down and mx < screen_w - SIDEBAR_WIDTH:
                gx = int((mx - canvas_offset_x) // (TILE_PIXEL*zoom))
                gy = int((my - canvas_offset_y) // (TILE_PIXEL*zoom))
                if 0 <= gx < grid_w and 0 <= gy < grid_h:
                    if selected_asset == len(assets)-1:
                        grid[gx][gy] = None
                    else:
                        grid[gx][gy] = selected_asset
            if right_down and mx < screen_w - SIDEBAR_WIDTH:
                gx = int((mx - canvas_offset_x) // (TILE_PIXEL*zoom))
                gy = int((my - canvas_offset_y) // (TILE_PIXEL*zoom))
                if 0 <= gx < grid_w and 0 <= gy < grid_h:
                    grid[gx][gy] = None

        elif event.type == pygame.MOUSEWHEEL:
            mx,my = pygame.mouse.get_pos()
            if mx < screen.get_width() - SIDEBAR_WIDTH:
                old_zoom = zoom
                zoom = clamp(zoom + 0.1*event.y, 0.25, 4.0)
                canvas_offset_x -= (mx - canvas_offset_x) * (zoom/old_zoom - 1)
                canvas_offset_y -= (my - canvas_offset_y) * (zoom/old_zoom - 1)
            else:
                toolbar_scroll -= event.y * 24
                toolbar_scroll = max(0, toolbar_scroll)

        elif event.type == pygame.KEYDOWN:
            if hex_bg_active:
                if event.key == pygame.K_RETURN:
                    rgb = hex_to_rgb(hex_bg_input)
                    if rgb: bg_color = rgb
                    hex_bg_input = ''; hex_bg_active = False
                elif event.key == pygame.K_BACKSPACE:
                    hex_bg_input = hex_bg_input[:-1]
                else:
                    ch = event.unicode.upper()
                    if ch and ch in '0123456789ABCDEF#' and len(hex_bg_input) < 7:
                        hex_bg_input += ch
            elif hex_grid_active:
                if event.key == pygame.K_RETURN:
                    rgb = hex_to_rgb(hex_grid_input)
                    if rgb: grid_color = rgb
                    hex_grid_input = ''; hex_grid_active = False
                elif event.key == pygame.K_BACKSPACE:
                    hex_grid_input = hex_grid_input[:-1]
                else:
                    ch = event.unicode.upper()
                    if ch and ch in '0123456789ABCDEF#' and len(hex_grid_input) < 7:
                        hex_grid_input += ch
            elif hex_ui_active:
                if event.key == pygame.K_RETURN:
                    rgb = hex_to_rgb(hex_ui_input)
                    if rgb: ui_color = rgb
                    hex_ui_input = ''; hex_ui_active = False
                elif event.key == pygame.K_BACKSPACE:
                    hex_ui_input = hex_ui_input[:-1]
                else:
                    ch = event.unicode.upper()
                    if ch and ch in '0123456789ABCDEF#' and len(hex_ui_input) < 7:
                        hex_ui_input += ch
            elif grid_w_active or grid_h_active:
                if event.key == pygame.K_BACKSPACE:
                    if grid_w_active: grid_w_input = grid_w_input[:-1]
                    else: grid_h_input = grid_h_input[:-1]
                else:
                    ch = event.unicode
                    if ch.isdigit():
                        if grid_w_active: grid_w_input += ch
                        else: grid_h_input += ch

    clock.tick(FPS)

pygame.quit()
sys.exit()
