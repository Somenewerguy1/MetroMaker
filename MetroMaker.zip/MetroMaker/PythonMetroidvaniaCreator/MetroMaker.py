import os
import sys
import pygame
import tkinter as tk
from tkinter import filedialog
import json

# ---------------------------
# MetroMaker with 2 layers: map & area
# - map layer uses assets/mapAssets
# - area layer uses assets/areaAssets
# - switch layers with topbar buttons Map / Area (centered and spread out)
# - inactive layer drawn at adjustable opacity (Layer Settings)
# - each layer has its own asset list and selected asset
# - save/load map.json stores both layers
# - everything underneath the top toolbar can be hidden with H or the flag below
# - Rect Mode: draw filled rectangles using top-left and bottom-right clicks
# ---------------------------

WINDOW_TITLE = "MetroMaker"
SIDEBAR_WIDTH = 320
DEFAULT_GRID_W = 64
DEFAULT_GRID_H = 64
TILE_PIXEL = 16
INITIAL_TILE_DISPLAY = 32
GRID_OPACITY_DEFAULT = 0.60
FPS = 60
TOPBAR_H = 40

# Scroll speed for the right toolbar (change to make faster/slower)
SIDEBAR_SCROLL_SPEED = 60

# Set this to True to hide everything under the top toolbar. You can also toggle at runtime with the H key.
HIDE_UNDER_TOPBAR = False

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ASSETS_FOLDER = os.path.join(BASE_DIR, "assets")
MAP_ASSETS_FOLDER = os.path.join(ASSETS_FOLDER, "mapAssets")
AREA_ASSETS_FOLDER = os.path.join(ASSETS_FOLDER, "areaAssets")
FONTS_FOLDER = os.path.join(BASE_DIR, "fonts")
ICON_FOLDER = os.path.join(BASE_DIR, "windowIcon")
SETTINGS_FILE = os.path.join(BASE_DIR, "settings.json")
MAP_FILE = os.path.join(BASE_DIR, "map.json")

# Default colors
bg_color = (20, 20, 20)
ui_color = (28, 28, 28)
grid_color = (80, 80, 80)
grid_opacity = GRID_OPACITY_DEFAULT

# Layer defaults
LAYERS = ['map', 'area']
ACTIVE_LAYER_DEFAULT = 'map'
INACTIVE_LAYER_OPACITY_DEFAULT = 0.60

# ---------------------------
# Helpers
# ---------------------------

def clamp(v, a, b):
    return max(a, min(b, v))


def hex_to_rgb(h):
    if not h:
        return None
    s = h.strip().lstrip('#')
    if len(s) != 6:
        return None
    try:
        return tuple(int(s[i:i+2], 16) for i in (0, 2, 4))
    except Exception:
        return None


def get_color(c):
    if isinstance(c, tuple) and len(c) >= 3:
        return c[:3]
    if isinstance(c, str):
        r = hex_to_rgb(c)
        if r:
            return r
    return (128, 128, 128)

# ---------------------------
# Init tkinter + pygame
# ---------------------------
root_tk = tk.Tk()
root_tk.withdraw()

pygame.init()
pygame.display.set_caption(WINDOW_TITLE)
info = pygame.display.Info()
START_W = int(info.current_w * 0.92)
START_H = int(info.current_h * 0.88)
screen = pygame.display.set_mode((START_W, START_H), pygame.RESIZABLE)
clock = pygame.time.Clock()

# optional icon
if os.path.isdir(ICON_FOLDER):
    for f in os.listdir(ICON_FOLDER):
        if f.lower().endswith('.png'):
            try:
                icon = pygame.image.load(os.path.join(ICON_FOLDER, f))
                pygame.display.set_icon(icon)
            except Exception:
                pass
            break

# ---------------------------
# Fonts
# ---------------------------
available_font_files = []
if os.path.isdir(FONTS_FOLDER):
    for f in sorted(os.listdir(FONTS_FOLDER)):
        if f.lower().endswith(('.ttf', '.otf')):
            available_font_files.append(os.path.join(FONTS_FOLDER, f))

if available_font_files:
    try:
        UI_FONT = pygame.font.Font(available_font_files[0], 16)
        UI_FONT_SMALL = pygame.font.Font(available_font_files[0], 14)
        UI_FONT_TITLE = pygame.font.Font(available_font_files[0], 18)
    except Exception:
        UI_FONT = pygame.font.SysFont('Courier', 16)
        UI_FONT_SMALL = pygame.font.SysFont('Courier', 14)
        UI_FONT_TITLE = pygame.font.SysFont('Courier', 18)
else:
    UI_FONT = pygame.font.SysFont('Courier', 16)
    UI_FONT_SMALL = pygame.font.SysFont('Courier', 14)
    UI_FONT_TITLE = pygame.font.SysFont('Courier', 18)

# ---------------------------
# Load assets per layer
# ---------------------------
def load_assets_from_folder(folder):
    assets_list = []
    names = []
    if os.path.isdir(folder):
        for fname in sorted(os.listdir(folder)):
            if fname.lower().endswith('.png'):
                path = os.path.join(folder, fname)
                try:
                    img = pygame.image.load(path).convert_alpha()
                    if img.get_width() != TILE_PIXEL or img.get_height() != TILE_PIXEL:
                        img = pygame.transform.scale(img, (TILE_PIXEL, TILE_PIXEL))
                    assets_list.append(img)
                    names.append(fname)
                except Exception:
                    print('Failed to load', path)
    # always append eraser as last tool for that layer
    assets_list.append(None)
    names.append('Eraser')
    return assets_list, names

assets_by_layer = {}
asset_names_by_layer = {}
assets_by_layer['map'], asset_names_by_layer['map'] = load_assets_from_folder(MAP_ASSETS_FOLDER)
assets_by_layer['area'], asset_names_by_layer['area'] = load_assets_from_folder(AREA_ASSETS_FOLDER)

# ---------------------------
# Preset colors
# ---------------------------
PRESET_COLORS = {
    'Black': (20,20,20),
    'Grey': (128,128,128),
    'White': (230,230,230),
    'Red': (200,50,50),
    'Green': (50,200,50),
    'Blue': (50,50,200),
    'Yellow': (200,200,50),
    'Cyan': (50,200,200),
    'Magenta': (200,50,200),
}

# ---------------------------
# Editor state (multi-layer)
# ---------------------------
active_layer = ACTIVE_LAYER_DEFAULT  # 'map' or 'area'
selected_asset_by_layer = {ly: 0 for ly in LAYERS}  # index into assets_by_layer[ly]
# grid sizes
grid_w = DEFAULT_GRID_W
grid_h = DEFAULT_GRID_H
# grids per layer (grid[x][y] storing asset index or None)
layers_grid = {ly: [[None for _ in range(grid_h)] for _ in range(grid_w)] for ly in LAYERS}

# canvas transform
canvas_offset_x = 0.0
canvas_offset_y = 0.0
zoom = 1.0

# layer visibility & opacity
layer_visible = {ly: True for ly in LAYERS}
inactive_layer_opacity = INACTIVE_LAYER_OPACITY_DEFAULT  # value 0..1 for non-active layers

# toolbar scroll (0 means content at top; negative values shift content up)
toolbar_scroll = 0

# UI input states
hex_bg_input = ''
hex_grid_input = ''
hex_ui_input = ''
hex_bg_active = False
hex_grid_active = False
hex_ui_active = False

grid_w_input = str(grid_w)
grid_h_input = str(grid_h)
grid_w_active = False
grid_h_active = False

slider_dragging = False

# modal
modal_active = False
modal_message = ''
modal_actions = {}

# mouse
left_down = False
right_down = False
middle_down = False
panning = False
last_pan_pos = (0,0)

selected_font_index = 0 if available_font_files else -1

SAVE_FEEDBACK_DURATION = FPS
save_feedback_timer = 0

HOVER_ALPHA = 80

# Rect mode
rect_mode = False
rect_start = None

# ---------------------------
# Settings & map persistence (now supports both layers)
# ---------------------------

def default_settings():
    return {
        "bg_color": '#141414',
        "ui_color": '#1c1c1c',
        "grid_color": '#505050',
        "grid_opacity": GRID_OPACITY_DEFAULT,
        "grid_w": DEFAULT_GRID_W,
        "grid_h": DEFAULT_GRID_H,
        "selected_font_index": -1,
        "active_layer": ACTIVE_LAYER_DEFAULT,
        "inactive_layer_opacity": INACTIVE_LAYER_OPACITY_DEFAULT,
        "layer_visible": layer_visible
    }

def save_settings():
    global bg_color, ui_color, grid_color, grid_opacity, grid_w, grid_h, selected_font_index, active_layer, inactive_layer_opacity, layer_visible
    try:
        def to_hex(c):
            if isinstance(c, tuple):
                return '#%02x%02x%02x' % (int(c[0]), int(c[1]), int(c[2]))
            if isinstance(c, str):
                return c
            return '#141414'
        s = {
            "bg_color": to_hex(bg_color),
            "ui_color": to_hex(ui_color),
            "grid_color": to_hex(grid_color),
            "grid_opacity": float(grid_opacity),
            "grid_w": int(grid_w),
            "grid_h": int(grid_h),
            "selected_font_index": int(selected_font_index),
            "active_layer": active_layer,
            "inactive_layer_opacity": float(inactive_layer_opacity),
            "layer_visible": layer_visible
        }
        with open(SETTINGS_FILE, 'w') as f:
            json.dump(s, f, indent=2)
        print('Settings saved')
    except Exception as e:
        print('Failed to save settings:', e)

def load_settings():
    global bg_color, ui_color, grid_color, grid_opacity, grid_w, grid_h, layers_grid, selected_font_index, active_layer, inactive_layer_opacity, layer_visible
    if not os.path.exists(SETTINGS_FILE):
        try:
            with open(SETTINGS_FILE, 'w') as f:
                json.dump(default_settings(), f, indent=2)
        except Exception:
            pass
        return
    try:
        with open(SETTINGS_FILE, 'r') as f:
            s = json.load(f)
        bg_color = get_color(s.get('bg_color'))
        ui_color = get_color(s.get('ui_color'))
        grid_color = get_color(s.get('grid_color'))
        grid_opacity = float(s.get('grid_opacity', GRID_OPACITY_DEFAULT))
        gw = int(s.get('grid_w', DEFAULT_GRID_W))
        gh = int(s.get('grid_h', DEFAULT_GRID_H))
        # ensure grids sized to settings
        for ly in LAYERS:
            layers_grid[ly] = [[None for _ in range(gh)] for _ in range(gw)]
        grid_w = gw; grid_h = gh
        selected_font_index = int(s.get('selected_font_index', -1))
        active_layer = s.get('active_layer', ACTIVE_LAYER_DEFAULT)
        inactive_layer_opacity = float(s.get('inactive_layer_opacity', INACTIVE_LAYER_OPACITY_DEFAULT)) if 'inactive_layer_opacity' in s else INACTIVE_LAYER_OPACITY_DEFAULT
        lv = s.get('layer_visible')
        if isinstance(lv, dict):
            for ly in LAYERS:
                layer_visible[ly] = bool(lv.get(ly, True))
    except Exception as e:
        print('Failed to load settings:', e)

def save_map():
    global grid_w, grid_h, layers_grid
    try:
        data = {
            "grid_w": grid_w,
            "grid_h": grid_h,
            "layers": {
                ly: layers_grid[ly] for ly in LAYERS
            }
        }
        with open(MAP_FILE, 'w') as f:
            json.dump(data, f, indent=2)
        print('Map saved to', MAP_FILE)
    except Exception as e:
        print('Failed to save map:', e)

def load_map():
    global layers_grid, grid_w, grid_h
    if not os.path.exists(MAP_FILE):
        return
    try:
        with open(MAP_FILE, 'r') as f:
            data = json.load(f)
        gw = max(1, int(data.get('grid_w', DEFAULT_GRID_W)))
        gh = max(1, int(data.get('grid_h', DEFAULT_GRID_H)))
        raw_layers = data.get('layers', {})
        # initialize new grids sized to gw x gh
        for ly in LAYERS:
            new_grid = [[None for _ in range(gh)] for _ in range(gw)]
            raw = raw_layers.get(ly, [])
            # legacy single-layer support: if MAP contains a top-level grid (list) use it as 'map'
            if not raw and isinstance(data.get('grid'), list) and ly == 'map':
                raw = data.get('grid', [])
            # populate
            for x in range(min(gw, len(raw))):
                col = raw[x]
                if not isinstance(col, list):
                    continue
                for y in range(min(gh, len(col))):
                    v = col[y]
                    if v is None:
                        new_grid[x][y] = None
                    else:
                        try:
                            iv = int(v)
                            new_grid[x][y] = iv
                        except Exception:
                            new_grid[x][y] = None
            layers_grid[ly] = new_grid
        grid_w, grid_h = gw, gh
        print('Map loaded from', MAP_FILE)
    except Exception as e:
        print('Failed to load map:', e)

# load persisted data
load_settings()
load_map()

# Ensure selected_asset indexes valid for newly loaded assets
for ly in LAYERS:
    if selected_asset_by_layer[ly] >= len(assets_by_layer[ly]):
        selected_asset_by_layer[ly] = 0

# ---------------------------
# Drawing helpers
# ---------------------------

def draw_text(surface, text, pos, font=None, color=(220,220,220)):
    if font is None:
        font = UI_FONT
    surface.blit(font.render(str(text), True, color), pos)

def visible_range(avail_w, avail_h):
    start_x = max(0, int((-canvas_offset_x) // (TILE_PIXEL*zoom)))
    start_y = max(0, int((-canvas_offset_y) // (TILE_PIXEL*zoom)))
    end_x = min(grid_w, int((avail_w - canvas_offset_x) // (TILE_PIXEL*zoom)) + 2)
    end_y = min(grid_h, int((avail_h - canvas_offset_y) // (TILE_PIXEL*zoom)) + 2)
    return start_x, start_y, end_x, end_y

def build_toolbar_layout(screen_w, screen_h, top_offset=TOPBAR_H):
    """
    Build absolute (screen) positions for toolbar elements.
    Return layout dict with rects and content_bottom_y (absolute).
    """
    toolbar_x = screen_w - SIDEBAR_WIDTH
    # start y below top bar
    y = top_offset + 12
    left = toolbar_x + 12
    layout = {'asset_rects': []}

    # assets header position
    layout['assets_title_y'] = y
    y += 28

    # use currently active layer's assets length
    cur_assets = assets_by_layer.get(active_layer, [])
    for i, surf in enumerate(cur_assets):
        r = pygame.Rect(left, y, INITIAL_TILE_DISPLAY, INITIAL_TILE_DISPLAY)
        layout['asset_rects'].append((i, r))
        y += INITIAL_TILE_DISPLAY + 10

    y += 10
    layout['bg_title_y'] = y
    y += 28

    layout['bg_color_rects'] = {}
    for name in PRESET_COLORS:
        r = pygame.Rect(left, y, 20, 20)
        layout['bg_color_rects'][name] = r
        y += 26

    y += 8
    layout['hex_bg_rect'] = pygame.Rect(left, y, SIDEBAR_WIDTH - (left - toolbar_x) - 20, 26)
    y += 36

    layout['grid_title_y'] = y
    y += 28
    layout['grid_color_rects'] = {}
    for name in PRESET_COLORS:
        r = pygame.Rect(left, y, 20, 20)
        layout['grid_color_rects'][name] = r
        y += 26

    y += 8
    layout['grid_opacity_slider'] = pygame.Rect(left, y, SIDEBAR_WIDTH - (left - toolbar_x) - 40, 10)
    y += 20
    layout['hex_grid_rect'] = pygame.Rect(left, y, SIDEBAR_WIDTH - (left - toolbar_x) - 20, 26)
    y += 36

    box_w = (SIDEBAR_WIDTH - (left - toolbar_x) - 40) // 2
    layout['grid_w_rect'] = pygame.Rect(left, y, box_w, 28)
    layout['grid_h_rect'] = pygame.Rect(left + box_w + 20, y, box_w, 28)
    y += 36
    layout['apply_grid_rect'] = pygame.Rect(left, y, SIDEBAR_WIDTH - (left - toolbar_x) - 20, 36)
    y += 44

    # Layer Settings section
    layout['layer_settings_y'] = y
    y += 28
    layout['layer_opacity_slider'] = pygame.Rect(left, y, SIDEBAR_WIDTH - (left - toolbar_x) - 40, 10)
    y += 24
    # checkboxes for visibility (we'll use small rects)
    layout['layer_visibility_rects'] = {}
    for ly in LAYERS:
        r = pygame.Rect(left, y, 16, 16)
        layout['layer_visibility_rects'][ly] = r
        y += 24

    y += 8
    layout['ui_title_y'] = y
    y += 28
    layout['ui_color_rects'] = {}
    for name in PRESET_COLORS:
        r = pygame.Rect(left, y, 20, 20)
        layout['ui_color_rects'][name] = r
        y += 26

    y += 8
    layout['hex_ui_rect'] = pygame.Rect(left, y, SIDEBAR_WIDTH - (left - toolbar_x) - 20, 26)
    y += 36

    layout['font_rects'] = []
    layout['fonts_title_y'] = y
    y += 28
    for idx, fp in enumerate(available_font_files):
        r = pygame.Rect(left, y, SIDEBAR_WIDTH - (left - toolbar_x) - 20, 24)
        layout['font_rects'].append((idx, r))
        y += 28

    # Rect mode checkbox (part of content, at end). It's easier to make it content so it scrolls with everything else
    y += 12
    layout['rect_mode_checkbox'] = pygame.Rect(left, y, 16, 16)
    layout['rect_mode_label_pos'] = (left + 22, y - 2)
    y += 28

    # content_bottom_y is the absolute bottom y used for content height calculation
    layout['content_bottom_y'] = y

    return layout

def draw_toolbar(surface, layout, screen_w, screen_h, top_offset=TOPBAR_H):
    toolbar_x = screen_w - SIDEBAR_WIDTH
    pygame.draw.rect(surface, get_color(ui_color), (toolbar_x, top_offset, SIDEBAR_WIDTH, screen_h - top_offset))
    left = toolbar_x + 12
    mx, my = pygame.mouse.get_pos()

    # Assets header shows which layer's assets are displayed
    draw_text(surface, f'Assets ({active_layer})', (left, layout['assets_title_y'] + toolbar_scroll), UI_FONT_TITLE)

    cur_assets = assets_by_layer.get(active_layer, [])
    cur_asset_names = asset_names_by_layer.get(active_layer, [])
    # draw each asset rect offset by toolbar_scroll
    for i, r in layout['asset_rects']:
        draw_r = r.move(0, toolbar_scroll)
        surf = cur_assets[i] if i < len(cur_assets) else None
        hovered = draw_r.collidepoint(mx, my)
        shadow = pygame.Rect(draw_r.x+2, draw_r.y+2, draw_r.w, draw_r.h)
        s = pygame.Surface((shadow.w, shadow.h), pygame.SRCALPHA)
        s.fill((0,0,0,40))
        surface.blit(s, shadow.topleft)

        if surf is None:
            eraser_box = pygame.Surface((draw_r.w, draw_r.h))
            eraser_box.fill((80,80,80))
            pygame.draw.line(eraser_box, (230,230,230), (4,4),(draw_r.w-4,draw_r.h-4),2)
            pygame.draw.line(eraser_box, (230,230,230), (draw_r.w-4,4),(4,draw_r.h-4),2)
            surface.blit(eraser_box, draw_r.topleft)
        else:
            img = pygame.transform.scale(surf, (draw_r.w, draw_r.h))
            surface.blit(img, draw_r.topleft)

        if i == selected_asset_by_layer.get(active_layer, 0):
            highlight_rect = draw_r.inflate(6, 6)
            pygame.draw.rect(surface, (240,200,60), highlight_rect, 3, border_radius=4)
        if hovered:
            hover_s = pygame.Surface((draw_r.w, draw_r.h), pygame.SRCALPHA)
            hover_s.fill((255,255,255,HOVER_ALPHA))
            surface.blit(hover_s, draw_r.topleft)
        nm = cur_asset_names[i] if i < len(cur_asset_names) else 'Eraser'
        draw_text(surface, nm, (draw_r.x + draw_r.w + 6, draw_r.y + (UI_FONT_SMALL.get_height()//4)), UI_FONT_SMALL)

    # Background Colors block
    draw_text(surface, 'Background Colors', (left, layout['bg_title_y'] + toolbar_scroll), UI_FONT_TITLE)
    for name, r in layout['bg_color_rects'].items():
        draw_r = r.move(0, toolbar_scroll)
        hovered = draw_r.collidepoint(mx, my)
        pygame.draw.rect(surface, get_color(PRESET_COLORS[name]), draw_r)
        pygame.draw.rect(surface, (200,200,200), draw_r, 1)
        if hovered:
            hover_s = pygame.Surface((draw_r.w, draw_r.h), pygame.SRCALPHA)
            hover_s.fill((255,255,255,HOVER_ALPHA))
            surface.blit(hover_s, draw_r.topleft)
        draw_text(surface, name, (draw_r.x + draw_r.w + 8, draw_r.y), UI_FONT_SMALL)

    hb = layout['hex_bg_rect'].move(0, toolbar_scroll)
    pygame.draw.rect(surface, (40,40,40), hb, border_radius=6)
    pygame.draw.rect(surface, (200,200,200), hb, 2 if hex_bg_active else 1, border_radius=6)
    draw_text(surface, hex_bg_input or '#RRGGBB', (hb.x+8, hb.y+4), UI_FONT_SMALL, color=(180,180,180))

    # Grid settings
    draw_text(surface, 'Grid Settings', (left, layout['grid_title_y'] + toolbar_scroll), UI_FONT_TITLE)
    for name, r in layout['grid_color_rects'].items():
        draw_r = r.move(0, toolbar_scroll)
        hovered = draw_r.collidepoint(mx, my)
        pygame.draw.rect(surface, get_color(PRESET_COLORS[name]), draw_r)
        pygame.draw.rect(surface, (200,200,200), draw_r, 1)
        if hovered:
            hover_s = pygame.Surface((draw_r.w, draw_r.h), pygame.SRCALPHA)
            hover_s.fill((255,255,255,HOVER_ALPHA))
            surface.blit(hover_s, draw_r.topleft)
        draw_text(surface, name, (draw_r.x + draw_r.w + 8, draw_r.y), UI_FONT_SMALL)

    slider = layout['grid_opacity_slider'].move(0, toolbar_scroll)
    pygame.draw.rect(surface, (60,60,60), slider, border_radius=4)
    filled = int(clamp(grid_opacity,0,1) * slider.w)
    if filled>0:
        pygame.draw.rect(surface, (140,140,140), (slider.x, slider.y, filled, slider.h), border_radius=4)
    pygame.draw.rect(surface, (200,200,200), slider, 1, border_radius=4)
    knob_x = slider.x + filled
    knob = pygame.Rect(knob_x-6, slider.y-6, 12, slider.h+12)
    pygame.draw.rect(surface, (220,220,220), knob, border_radius=6)

    hg = layout['hex_grid_rect'].move(0, toolbar_scroll)
    pygame.draw.rect(surface, (40,40,40), hg, border_radius=6)
    pygame.draw.rect(surface, (200,200,200), hg, 2 if hex_grid_active else 1, border_radius=6)
    draw_text(surface, hex_grid_input or '#RRGGBB', (hg.x+8, hg.y+4), UI_FONT_SMALL, color=(180,180,180))

    gw = layout['grid_w_rect'].move(0, toolbar_scroll); gh = layout['grid_h_rect'].move(0, toolbar_scroll)
    pygame.draw.rect(surface, (40,40,40), gw, border_radius=6)
    pygame.draw.rect(surface, (200,200,200), gw, 2 if grid_w_active else 1, border_radius=6)
    pygame.draw.rect(surface, (40,40,40), gh, border_radius=6)
    pygame.draw.rect(surface, (200,200,200), gh, 2 if grid_h_active else 1, border_radius=6)
    draw_text(surface, grid_w_input, (gw.x+8, gw.y+4), UI_FONT_SMALL)
    draw_text(surface, grid_h_input, (gh.x+8, gh.y+4), UI_FONT_SMALL)

    ab = layout['apply_grid_rect'].move(0, toolbar_scroll)
    pygame.draw.rect(surface, (70,70,90), ab, border_radius=8)
    pygame.draw.rect(surface, (200,200,220), ab, 1, border_radius=8)
    draw_text(surface, 'Apply Grid Size (resets)', (ab.x+8, ab.y+6), UI_FONT)

    # Layer settings
    draw_text(surface, 'Layer Settings', (left, layout['layer_settings_y'] + toolbar_scroll), UI_FONT_TITLE)
    los = layout['layer_opacity_slider'].move(0, toolbar_scroll)
    pygame.draw.rect(surface, (60,60,60), los, border_radius=4)
    filled2 = int(clamp(inactive_layer_opacity,0,1) * los.w)
    if filled2>0:
        pygame.draw.rect(surface, (140,140,140), (los.x, los.y, filled2, los.h), border_radius=4)
    pygame.draw.rect(surface, (200,200,200), los, 1, border_radius=4)
    draw_text(surface, f'Inactive layer opacity: {int(inactive_layer_opacity*100)}%', (los.x, los.y+los.h+4), UI_FONT_SMALL)

    # visibility toggles
    for ly in LAYERS:
        r = layout['layer_visibility_rects'][ly].move(0, toolbar_scroll)
        pygame.draw.rect(surface, (180,180,180), r)
        if layer_visible.get(ly, True):
            pygame.draw.line(surface, (0,150,0), (r.x+2, r.y+ r.h//2), (r.x + r.w//2, r.y + r.h - 3), 3)
            pygame.draw.line(surface, (0,150,0), (r.x + r.w//2, r.y + r.h - 3), (r.x + r.w - 2, r.y+2), 3)
        draw_text(surface, f'{ly} visible', (r.x + r.w + 6, r.y-2), UI_FONT_SMALL)

    # UI colors block
    draw_text(surface, 'UI Colors', (left, layout['ui_title_y'] + toolbar_scroll), UI_FONT_TITLE)
    for name, r in layout['ui_color_rects'].items():
        draw_r = r.move(0, toolbar_scroll)
        hovered = draw_r.collidepoint(mx, my)
        pygame.draw.rect(surface, get_color(PRESET_COLORS[name]), draw_r)
        pygame.draw.rect(surface, (200,200,200), draw_r, 1)
        if hovered:
            hover_s = pygame.Surface((draw_r.w, draw_r.h), pygame.SRCALPHA)
            hover_s.fill((255,255,255,HOVER_ALPHA))
            surface.blit(hover_s, draw_r.topleft)
        draw_text(surface, name, (draw_r.x + draw_r.w + 8, draw_r.y), UI_FONT_SMALL)

    hu = layout['hex_ui_rect'].move(0, toolbar_scroll)
    pygame.draw.rect(surface, (40,40,40), hu, border_radius=6)
    pygame.draw.rect(surface, (200,200,200), hu, 2 if hex_ui_active else 1, border_radius=6)
    draw_text(surface, hex_ui_input or '#RRGGBB', (hu.x+8, hu.y+4), UI_FONT_SMALL, color=(180,180,180))

    draw_text(surface, 'Fonts', (left, layout['fonts_title_y'] + toolbar_scroll), UI_FONT_TITLE)
    for idx, r in layout['font_rects']:
        draw_r = r.move(0, toolbar_scroll)
        hovered = draw_r.collidepoint(mx, my)
        pygame.draw.rect(surface, (45,45,45), draw_r, border_radius=6)
        if idx == selected_font_index:
            pygame.draw.rect(surface, (230,200,80), draw_r, 2, border_radius=6)
        if hovered:
            hover_s = pygame.Surface((draw_r.w, draw_r.h), pygame.SRCALPHA)
            hover_s.fill((255,255,255,HOVER_ALPHA))
            surface.blit(hover_s, draw_r.topleft)
        fname = os.path.basename(available_font_files[idx]) if idx < len(available_font_files) else 'N/A'
        draw_text(surface, fname, (draw_r.x+6, draw_r.y+4), UI_FONT_SMALL)

    # Rect Mode toggle checkbox (part of content)
    r = layout['rect_mode_checkbox'].move(0, toolbar_scroll)
    hovered = r.collidepoint(mx, my)
    pygame.draw.rect(surface, (180,180,180), r)
    if rect_mode:
        pygame.draw.line(surface, (0,150,0), (r.x+2, r.y + r.h//2), (r.x + r.w//2, r.y + r.h - 3), 3)
        pygame.draw.line(surface, (0,150,0), (r.x + r.w//2, r.y + r.h - 3), (r.x + r.w - 2, r.y+2), 3)
    if hovered:
        hover_s = pygame.Surface((r.w, r.h), pygame.SRCALPHA)
        hover_s.fill((255,255,255,HOVER_ALPHA))
        surface.blit(hover_s, r.topleft)
    draw_text(surface, 'Rect Mode', layout['rect_mode_label_pos'], UI_FONT_SMALL if toolbar_scroll == 0 else UI_FONT_SMALL)  # label position is absolute; separate from checkbox y

    # Return interactive rects (un-moved positions for reference)
    return {
        'knob_rect': knob,
        'slider_rect': layout['grid_opacity_slider'],
        'layer_opacity_rect': layout['layer_opacity_slider'],
        'layer_visibility_rects': layout['layer_visibility_rects'],
        'bg_color_rects': layout['bg_color_rects'],
        'grid_color_rects': layout['grid_color_rects'],
        'asset_rects': layout['asset_rects'],
        'hex_bg_rect': layout['hex_bg_rect'],
        'hex_grid_rect': layout['hex_grid_rect'],
        'hex_ui_rect': layout['hex_ui_rect'],
        'grid_w_rect': layout['grid_w_rect'],
        'grid_h_rect': layout['grid_h_rect'],
        'apply_grid_rect': layout['apply_grid_rect'],
        'ui_color_rects': layout['ui_color_rects'],
        'font_rects': layout['font_rects'],
        'rect_mode_checkbox': layout['rect_mode_checkbox'],
        'content_bottom_y': layout['content_bottom_y'],
        'assets_title_y': layout['assets_title_y'],
        'bg_title_y': layout['bg_title_y'],
        'grid_title_y': layout['grid_title_y'],
        'layer_settings_y': layout['layer_settings_y'],
        'ui_title_y': layout['ui_title_y'],
        'fonts_title_y': layout['fonts_title_y']
    }

# ---------------------------
# Modal handling
# ---------------------------

def open_modal(message, on_proceed, on_cancel):
    global modal_active, modal_message, modal_actions
    modal_active = True
    modal_message = message
    modal_actions = {'Proceed': on_proceed, 'Cancel': on_cancel}

# ---------------------------
# Export helper - merges layers (map below, area above)
# ---------------------------

def export_map_dialog():
    # compute extents
    any_nonempty = False
    for ly in LAYERS:
        for x in range(grid_w):
            if any(layers_grid[ly][x][y] is not None for y in range(grid_h)):
                any_nonempty = True
                break
        if any_nonempty:
            break

    if not any_nonempty:
        ew, eh = 1, 1
    else:
        maxx = 0; maxy = 0
        for ly in LAYERS:
            for x in range(grid_w):
                if any(layers_grid[ly][x][y] is not None for y in range(grid_h)):
                    maxx = max(maxx, x)
            for y in range(grid_h):
                if any(layers_grid[ly][x][y] is not None for x in range(grid_w)):
                    maxy = max(maxy, y)
        ew, eh = maxx+1, maxy+1
    surf = pygame.Surface((ew*TILE_PIXEL, eh*TILE_PIXEL), pygame.SRCALPHA)
    surf.fill(bg_color)
    # draw map layer then area layer
    for ly in LAYERS:
        for x in range(ew):
            for y in range(eh):
                idx = layers_grid[ly][x][y] if x < len(layers_grid[ly]) and y < len(layers_grid[ly][0]) else None
                if idx is not None:
                    assets_list = assets_by_layer[ly]
                    if 0 <= idx < len(assets_list):
                        tile_surf = assets_list[idx]
                        if tile_surf:
                            surf.blit(tile_surf, (x*TILE_PIXEL, y*TILE_PIXEL))
    path = filedialog.asksaveasfilename(defaultextension='.png', filetypes=[('PNG', '*.png')])
    if path:
        try:
            pygame.image.save(surf, path)
            print('Saved', path)
        except Exception as e:
            print('Export failed:', e)

# ---------------------------
# Main loop
# ---------------------------

running = True
while running:
    screen_w, screen_h = screen.get_size()
    screen.fill(bg_color)

    # Top toolbar (sticky)
    topbar_rect = pygame.Rect(0, 0, screen_w, TOPBAR_H)
    pygame.draw.rect(screen, get_color(ui_color), topbar_rect)
    pygame.draw.line(screen, (80,80,80), (0, TOPBAR_H-1), (screen_w, TOPBAR_H-1))

    # Topbar buttons: place Export/Save/Clear on left; place layer buttons in the center
    left_x = 12
    save_button_rect = pygame.Rect(left_x, 6, 110, TOPBAR_H-12)
    left_x = save_button_rect.right + 10
    clear_button_rect = pygame.Rect(left_x, 6, 110, TOPBAR_H-12)
    left_x = clear_button_rect.right + 10
    export_button_rect = pygame.Rect(left_x, 6, 160, TOPBAR_H-12)

    # Center the layer buttons with larger spacing
    layer_button_w = 140
    layer_spacing = 48
    center_x = screen_w // 2
    total_w = layer_button_w * 2 + layer_spacing
    map_x = center_x - total_w // 2
    area_x = map_x + layer_button_w + layer_spacing
    map_layer_button_rect = pygame.Rect(map_x, 6, layer_button_w, TOPBAR_H-12)
    area_layer_button_rect = pygame.Rect(area_x, 6, layer_button_w, TOPBAR_H-12)

    # active layer indicator pill shifted further to the right of the area button
    indicator_w = 180
    indicator_margin = 28
    indicator_rect = pygame.Rect(area_layer_button_rect.right + indicator_margin, 8, indicator_w, TOPBAR_H-16)
    # if indicator would overlap the sidebar, place it to the left of the map button instead
    max_indicator_right = screen_w - SIDEBAR_WIDTH - 12
    if indicator_rect.right > max_indicator_right:
        alt_x = map_layer_button_rect.x - indicator_margin - indicator_w
        # fallback: if alt_x would be negative, center under the two buttons
        if alt_x < 8:
            indicator_rect.x = max(8, (map_layer_button_rect.x + area_layer_button_rect.right - indicator_w) // 2)
        else:
            indicator_rect.x = alt_x

    # Draw Save
    if save_feedback_timer > 0:
        pulse = int((save_feedback_timer / SAVE_FEEDBACK_DURATION) * 50)
        color = (max(0, 60 - pulse), max(0, 90 - pulse), max(0, 60 - pulse))
        pygame.draw.rect(screen, color, save_button_rect, border_radius=6)
        draw_text(screen, 'Saved', (save_button_rect.x+12, save_button_rect.y+6), UI_FONT, color=(200,255,200))
    else:
        pygame.draw.rect(screen, (50,50,70), save_button_rect, border_radius=6)
        draw_text(screen, 'Save', (save_button_rect.x+12, save_button_rect.y+6), UI_FONT, color=(220,220,220))

    # Clear
    pygame.draw.rect(screen, (70,50,50), clear_button_rect, border_radius=6)
    draw_text(screen, 'Clear', (clear_button_rect.x+28, clear_button_rect.y+6), UI_FONT, color=(220,220,220))

    # Export (left)
    pygame.draw.rect(screen, (50,70,50), export_button_rect, border_radius=6)
    draw_text(screen, 'Export (PNG)', (export_button_rect.x+12, export_button_rect.y+6), UI_FONT, color=(220,220,220))

    # Layer switching buttons (center) - labels changed to 'Map' and 'Area'
    pygame.draw.rect(screen, (60,60,100) if active_layer == 'map' else (40,40,40), map_layer_button_rect, border_radius=6)
    draw_text(screen, 'Map', (map_layer_button_rect.x+16, map_layer_button_rect.y+6), UI_FONT, color=(220,220,220))
    pygame.draw.rect(screen, (60,60,100) if active_layer == 'area' else (40,40,40), area_layer_button_rect, border_radius=6)
    draw_text(screen, 'Area', (area_layer_button_rect.x+20, area_layer_button_rect.y+6), UI_FONT, color=(220,220,220))

    # Active layer indicator pill (more separated)
    pygame.draw.rect(screen, (30,30,30), indicator_rect, border_radius=10)
    pygame.draw.rect(screen, (200,200,200), indicator_rect, 1, border_radius=10)
    label_text = f'Active: {active_layer.upper()}'
    draw_text(screen, label_text, (indicator_rect.x + 12, indicator_rect.y + 6), UI_FONT, color=(220,220,220))

    # Calculate canvas size (used both when hidden and visible)
    canvas_w = max(0, screen_w - SIDEBAR_WIDTH)
    canvas_h = max(0, screen_h - TOPBAR_H)
    canvas_rect = pygame.Rect(0, TOPBAR_H, canvas_w, canvas_h)

    # Build toolbar layout (we need layout for events even before drawing the toolbar)
    layout = build_toolbar_layout(screen_w, screen_h, top_offset=TOPBAR_H)

    # clamp toolbar_scroll based on content height so you can't over-scroll
    content_bottom_y = layout.get('content_bottom_y', TOPBAR_H)
    max_scroll = max(0, content_bottom_y - screen_h)  # how many pixels content extends below the window
    # toolbar_scroll negative moves content up; allow range [-max_scroll, 0]
    toolbar_scroll = clamp(toolbar_scroll, -max_scroll, 0)

    # -------------------------
    # Draw canvas (tiles + grid) into a clipped area so nothing can draw under the right toolbar
    # -------------------------
    screen.set_clip(canvas_rect)  # restrict all drawing to canvas_rect
    sx, sy, ex, ey = visible_range(canvas_w, canvas_h)
    # Draw layers in order: map then area. Active layer drawn at full alpha, inactive drawn at inactive_layer_opacity
    for ly in LAYERS:
        if not layer_visible.get(ly, True):
            continue
        draw_opacity = 1.0 if ly == active_layer else inactive_layer_opacity
        # draw tiles for visible cells
        for gx in range(sx, ex):
            for gy in range(sy, ey):
                try:
                    idx = layers_grid[ly][gx][gy]
                except Exception:
                    idx = None
                if idx is not None:
                    assets_list = assets_by_layer[ly]
                    if 0 <= idx < len(assets_list):
                        tile = assets_list[idx]
                        if tile is not None:
                            dest = pygame.Rect(
                                int(canvas_offset_x + gx*TILE_PIXEL*zoom),
                                int(TOPBAR_H + canvas_offset_y + gy*TILE_PIXEL*zoom),
                                int(TILE_PIXEL*zoom), int(TILE_PIXEL*zoom)
                            )
                            if draw_opacity >= 0.999:
                                screen.blit(pygame.transform.scale(tile, (dest.w, dest.h)), dest.topleft)
                            else:
                                img = pygame.transform.scale(tile, (dest.w, dest.h)).copy()
                                alpha = int(clamp(draw_opacity, 0.0, 1.0) * 255)
                                img.fill((255,255,255,alpha), special_flags=pygame.BLEND_RGBA_MULT)
                                screen.blit(img, dest.topleft)

    # Draw grid lines overlay (single grid) inside clipped area
    grid_surf = pygame.Surface((canvas_w, canvas_h), pygame.SRCALPHA)
    alpha = int(clamp(grid_opacity, 0, 1) * 255)
    line_color = (*grid_color, alpha)
    for gx in range(sx, ex+1):
        px = int(canvas_offset_x + gx*TILE_PIXEL*zoom)
        pygame.draw.line(grid_surf, line_color, (px,0), (px, canvas_h))
    for gy in range(sy, ey+1):
        py = int(canvas_offset_y + gy*TILE_PIXEL*zoom)
        pygame.draw.line(grid_surf, line_color, (0,py), (canvas_w, py))
    screen.blit(grid_surf, (0, TOPBAR_H))

    # done drawing canvas - reset clip
    screen.set_clip(None)

    # If requested, draw a cover over the canvas area (this hides canvas visually but not the sidebar)
    if HIDE_UNDER_TOPBAR:
        cover = pygame.Surface((canvas_w, canvas_h))
        cover.fill(bg_color)
        screen.blit(cover, (0, TOPBAR_H))

    # -------------------------
    # Draw toolbar last so it sits on top of the canvas/cover
    # -------------------------
    widget_draw_info = draw_toolbar(screen, layout, screen_w, screen_h, top_offset=TOPBAR_H)

    # get slider_rect (unmoved) and compute its moved version for interactions
    slider_rect = widget_draw_info.get('slider_rect')
    slider_rect_moved = slider_rect.move(0, toolbar_scroll) if slider_rect else None
    knob_rect = widget_draw_info.get('knob_rect')
    layer_opacity_rect = widget_draw_info.get('layer_opacity_rect')
    layer_visibility_rects = widget_draw_info.get('layer_visibility_rects')

    # If Rect mode is active, display prompt text
    if rect_mode:
        if rect_start is None:
            msg = 'Rect Mode: click top-left tile'
        else:
            msg = 'Rect Mode: click bottom-right tile'
        draw_text(screen, msg, (8, TOPBAR_H+8), UI_FONT)

    # Modal draw (drawn on top of everything) - single correct block
    if modal_active:
        overlay = pygame.Surface((screen_w, screen_h), pygame.SRCALPHA)
        overlay.fill((0,0,0,150))
        screen.blit(overlay, (0,0))
        mw, mh = 520, 160
        mx = (screen_w - mw)//2
        my = (screen_h - mh)//2
        panel = pygame.Rect(mx,my,mw,mh)
        pygame.draw.rect(screen, (34,34,48), panel, border_radius=12)
        pygame.draw.rect(screen, (200,200,220), panel, 2, border_radius=12)
        # message wrap
        lines = modal_message.split('\n')
        for i, line in enumerate(lines):
            draw_text(screen, line, (mx+20, my+18 + i*22), UI_FONT)
        btn_w, btn_h = 120, 36
        proceed_rect = pygame.Rect(mx + mw - btn_w - 20, my + mh - btn_h - 16, btn_w, btn_h)
        cancel_rect = pygame.Rect(proceed_rect.x - btn_w - 12, proceed_rect.y, btn_w, btn_h)
        pygame.draw.rect(screen, (80,100,80), proceed_rect, border_radius=10)
        pygame.draw.rect(screen, (100,80,80), cancel_rect, border_radius=10)
        draw_text(screen, 'Proceed', (proceed_rect.x+18, proceed_rect.y+8), UI_FONT)
        draw_text(screen, 'Cancel', (cancel_rect.x+28, cancel_rect.y+8), UI_FONT)

    pygame.display.flip()

    if save_feedback_timer > 0:
        save_feedback_timer -= 1

    # ---------------------------
    # Events
    # ---------------------------
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        elif event.type == pygame.VIDEORESIZE:
            new_w = max(640, event.w)
            new_h = max(480, event.h)
            screen = pygame.display.set_mode((new_w, new_h), pygame.RESIZABLE)

        # Modal interactions (capture clicks while open)
        if modal_active:
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                mx_, my_ = pygame.mouse.get_pos()
                try:
                    if 'cancel_rect' in locals() and cancel_rect and cancel_rect.collidepoint(mx_, my_):
                        modal_active = False
                        if 'Cancel' in modal_actions and callable(modal_actions['Cancel']):
                            modal_actions['Cancel']()
                        modal_actions = {}
                    elif 'proceed_rect' in locals() and proceed_rect and proceed_rect.collidepoint(mx_, my_):
                        modal_active = False
                        if 'Proceed' in modal_actions and callable(modal_actions['Proceed']):
                            modal_actions['Proceed']()
                        modal_actions = {}
                except Exception:
                    modal_active = False
                    modal_actions = {}
            continue

        if event.type == pygame.MOUSEBUTTONDOWN:
            mx, my = pygame.mouse.get_pos()

            # Topbar buttons (always on top)
            if event.button == 1:
                if save_button_rect.collidepoint(mx, my):
                    save_settings()
                    save_map()
                    save_feedback_timer = SAVE_FEEDBACK_DURATION
                    continue
                elif clear_button_rect.collidepoint(mx, my):
                    def do_clear():
                        global layers_grid
                        for ly in LAYERS:
                            layers_grid[ly] = [[None for _ in range(grid_h)] for _ in range(grid_w)]
                        print('All layers cleared')
                    open_modal('Clear all tiles on all layers? This will erase the current drawing.\nProceed?', do_clear, lambda: None)
                    continue
                elif export_button_rect.collidepoint(mx, my):
                    export_map_dialog()
                    continue
                elif map_layer_button_rect.collidepoint(mx, my):
                    active_layer = 'map'
                    continue
                elif area_layer_button_rect.collidepoint(mx, my):
                    active_layer = 'area'
                    continue

            # Sidebar area (right of screen and below topbar)
            if mx >= screen.get_width() - SIDEBAR_WIDTH and my >= TOPBAR_H and event.button == 1:
                # asset clicks (only for active layer) - account for toolbar_scroll when checking positions
                for i, r in layout['asset_rects']:
                    draw_r = r.move(0, toolbar_scroll)
                    if draw_r.collidepoint(mx, my):
                        selected_asset_by_layer[active_layer] = i
                        left_down = False
                        break
                # bg presets
                for name, r in layout['bg_color_rects'].items():
                    draw_r = r.move(0, toolbar_scroll)
                    if draw_r.collidepoint(mx, my):
                        bg_color = PRESET_COLORS[name]
                        break
                # hex bg box
                if layout['hex_bg_rect'].move(0, toolbar_scroll).collidepoint(mx, my):
                    hex_bg_active = True
                    hex_grid_active = hex_ui_active = False
                    grid_w_active = grid_h_active = False
                # grid color presets
                for name, r in layout['grid_color_rects'].items():
                    draw_r = r.move(0, toolbar_scroll)
                    if draw_r.collidepoint(mx, my):
                        grid_color = PRESET_COLORS[name]
                        break
                # slider (start drag)
                if slider_rect_moved and slider_rect_moved.collidepoint(mx, my):
                    slider_dragging = True
                    rel = clamp((mx - slider_rect_moved.x) / slider_rect_moved.w, 0.0, 1.0)
                    grid_opacity = rel
                # hex grid box
                if layout['hex_grid_rect'].move(0, toolbar_scroll).collidepoint(mx, my):
                    hex_grid_active = True
                    hex_bg_active = hex_ui_active = False
                    grid_w_active = grid_h_active = False
                # grid size boxes
                if layout['grid_w_rect'].move(0, toolbar_scroll).collidepoint(mx, my):
                    grid_w_active, grid_h_active = True, False
                elif layout['grid_h_rect'].move(0, toolbar_scroll).collidepoint(mx, my):
                    grid_w_active, grid_h_active = False, True
                # apply grid button
                if layout['apply_grid_rect'].move(0, toolbar_scroll).collidepoint(mx, my):
                    if grid_w_input.isdigit() and grid_h_input.isdigit():
                        new_w = max(1, int(grid_w_input))
                        new_h = max(1, int(grid_h_input))
                        def do_apply():
                            global grid_w, grid_h, layers_grid, canvas_offset_x, canvas_offset_y, zoom, grid_w_input, grid_h_input
                            grid_w, grid_h = new_w, new_h
                            for ly in LAYERS:
                                layers_grid[ly] = [[None for _ in range(grid_h)] for _ in range(grid_w)]
                            canvas_offset_x = 0.0; canvas_offset_y = 0.0; zoom = 1.0
                            grid_w_input = str(grid_w); grid_h_input = str(grid_h)
                        open_modal('Change grid size? This will erase the current drawing.\nProceed?', do_apply, lambda: None)
                # layer opacity slider start drag
                if layout['layer_opacity_slider'].move(0, toolbar_scroll).collidepoint(mx, my):
                    inactive_layer_opacity = clamp((mx - layout['layer_opacity_slider'].x) / layout['layer_opacity_slider'].w, 0.0, 1.0)
                # layer visibility toggles
                for ly, r in layout['layer_visibility_rects'].items():
                    draw_r = r.move(0, toolbar_scroll)
                    if draw_r.collidepoint(mx, my):
                        layer_visible[ly] = not layer_visible.get(ly, True)
                        break
                # ui color presets
                for name, r in layout['ui_color_rects'].items():
                    draw_r = r.move(0, toolbar_scroll)
                    if draw_r.collidepoint(mx, my):
                        ui_color = PRESET_COLORS[name]
                        break
                # hex ui box
                if layout['hex_ui_rect'].move(0, toolbar_scroll).collidepoint(mx, my):
                    hex_ui_active = True
                    hex_bg_active = hex_grid_active = False
                    grid_w_active = grid_h_active = False
                # fonts selection
                for idx, r in layout['font_rects']:
                    draw_r = r.move(0, toolbar_scroll)
                    if draw_r.collidepoint(mx, my):
                        selected_font_index = idx
                        try:
                            UI_FONT = pygame.font.Font(available_font_files[selected_font_index], 16)
                            UI_FONT_SMALL = pygame.font.Font(available_font_files[selected_font_index], 14)
                            UI_FONT_TITLE = pygame.font.Font(available_font_files[selected_font_index], 18)
                        except Exception:
                            pass
                # Rect mode toggle (checkbox as part of content)
                if layout['rect_mode_checkbox'].move(0, toolbar_scroll).collidepoint(mx, my):
                    rect_mode = not rect_mode
                    rect_start = None

            else:
                # clicked in canvas area — respond to mouse button types
                if mx < screen.get_width() - SIDEBAR_WIDTH and my >= TOPBAR_H:
                    gx = int((mx - canvas_offset_x) // (TILE_PIXEL * zoom))
                    gy = int((my - TOPBAR_H - canvas_offset_y) // (TILE_PIXEL * zoom))
                    if event.button == 1:
                        # Rectangle mode handling
                        if 0 <= gx < grid_w and 0 <= gy < grid_h and rect_mode:
                            if rect_start is None:
                                rect_start = (gx, gy)
                            else:
                                x0, y0 = rect_start
                                x1, y1 = gx, gy
                                xmin, xmax = min(x0, x1), max(x0, x1)
                                ymin, ymax = min(y0, y1), max(y0, y1)
                                for xx in range(xmin, xmax+1):
                                    for yy in range(ymin, ymax+1):
                                        if 0 <= xx < grid_w and 0 <= yy < grid_h:
                                            if selected_asset_by_layer[active_layer] == len(assets_by_layer[active_layer]) - 1:
                                                layers_grid[active_layer][xx][yy] = None
                                            else:
                                                layers_grid[active_layer][xx][yy] = selected_asset_by_layer[active_layer]
                                rect_start = None
                            continue

                        left_down = True
                        if 0 <= gx < grid_w and 0 <= gy < grid_h:
                            if selected_asset_by_layer[active_layer] == len(assets_by_layer[active_layer]) - 1:
                                layers_grid[active_layer][gx][gy] = None
                            else:
                                layers_grid[active_layer][gx][gy] = selected_asset_by_layer[active_layer]
                    elif event.button == 3:
                        right_down = True
                        if 0 <= gx < grid_w and 0 <= gy < grid_h:
                            layers_grid[active_layer][gx][gy] = None
                    elif event.button == 2:
                        middle_down = True
                        panning = True
                        last_pan_pos = event.pos

        elif event.type == pygame.MOUSEBUTTONUP:
            if event.button == 1:
                left_down = False
            elif event.button == 3:
                right_down = False
            elif event.button == 2:
                middle_down = False; panning = False
            slider_dragging = False

        elif event.type == pygame.MOUSEMOTION:
            mx,my = event.pos
            if panning and middle_down:
                dx, dy = mx - last_pan_pos[0], my - last_pan_pos[1]
                canvas_offset_x += dx; canvas_offset_y += dy
                last_pan_pos = (mx,my)
            if slider_dragging and slider_rect_moved:
                rel = clamp((mx - slider_rect_moved.x)/slider_rect_moved.w, 0.0, 1.0)
                grid_opacity = rel
            # drag painting/erasing only in canvas area
            if left_down and mx < screen_w - SIDEBAR_WIDTH and my >= TOPBAR_H:
                gx = int((mx - canvas_offset_x) // (TILE_PIXEL*zoom))
                gy = int((my - TOPBAR_H - canvas_offset_y) // (TILE_PIXEL*zoom))
                if 0 <= gx < grid_w and 0 <= gy < grid_h:
                    if selected_asset_by_layer[active_layer] == len(assets_by_layer[active_layer]) - 1:
                        layers_grid[active_layer][gx][gy] = None
                    else:
                        layers_grid[active_layer][gx][gy] = selected_asset_by_layer[active_layer]
            if right_down and mx < screen_w - SIDEBAR_WIDTH and my >= TOPBAR_H:
                gx = int((mx - canvas_offset_x) // (TILE_PIXEL*zoom))
                gy = int((my - TOPBAR_H - canvas_offset_y) // (TILE_PIXEL*zoom))
                if 0 <= gx < grid_w and 0 <= gy < grid_h:
                    layers_grid[active_layer][gx][gy] = None

        elif event.type == pygame.MOUSEWHEEL:
            mx,my = pygame.mouse.get_pos()
            # zoom on canvas, scroll in sidebar
            if mx < screen.get_width() - SIDEBAR_WIDTH and my >= TOPBAR_H:
                old_zoom = zoom
                zoom = clamp(zoom + 0.1*event.y, 0.25, 4.0)
                canvas_offset_x -= (mx - canvas_offset_x) * (zoom/old_zoom - 1)
                canvas_offset_y -= (my - TOPBAR_H - canvas_offset_y) * (zoom/old_zoom - 1)
            elif mx >= screen.get_width() - SIDEBAR_WIDTH and my >= TOPBAR_H:
                # toolbar_scroll negative moves content up
                toolbar_scroll += event.y * SIDEBAR_SCROLL_SPEED
                # clamp here as well
                toolbar_scroll = clamp(toolbar_scroll, -max_scroll, 0)

        elif event.type == pygame.KEYDOWN:
            # toggle hide/show under topbar with H
            if event.key == pygame.K_h:
                HIDE_UNDER_TOPBAR = not HIDE_UNDER_TOPBAR
                continue
            if hex_bg_active:
                if event.key == pygame.K_RETURN:
                    rgb = hex_to_rgb(hex_bg_input)
                    if rgb: bg_color = rgb
                    hex_bg_input = ''; hex_bg_active = False
                elif event.key == pygame.K_BACKSPACE:
                    hex_bg_input = hex_bg_input[:-1]
                else:
                    ch = event.unicode.upper()
                    if ch and ch in '0123456789ABCDEF#' and len(hex_bg_input) < 7:
                        hex_bg_input += ch
            elif hex_grid_active:
                if event.key == pygame.K_RETURN:
                    rgb = hex_to_rgb(hex_grid_input)
                    if rgb: grid_color = rgb
                    hex_grid_input = ''; hex_grid_active = False
                elif event.key == pygame.K_BACKSPACE:
                    hex_grid_input = hex_grid_input[:-1]
                else:
                    ch = event.unicode.upper()
                    if ch and ch in '0123456789ABCDEF#' and len(hex_grid_input) < 7:
                        hex_grid_input += ch
            elif hex_ui_active:
                if event.key == pygame.K_RETURN:
                    rgb = hex_to_rgb(hex_ui_input)
                    if rgb: ui_color = rgb
                    hex_ui_input = ''; hex_ui_active = False
                elif event.key == pygame.K_BACKSPACE:
                    hex_ui_input = hex_ui_input[:-1]
                else:
                    ch = event.unicode.upper()
                    if ch and ch in '0123456789ABCDEF#' and len(hex_ui_input) < 7:
                        hex_ui_input += ch
            elif grid_w_active or grid_h_active:
                if event.key == pygame.K_BACKSPACE:
                    if grid_w_active: grid_w_input = grid_w_input[:-1]
                    else: grid_h_input = grid_h_input[:-1]
                else:
                    ch = event.unicode
                    if ch.isdigit():
                        if grid_w_active: grid_w_input += ch
                        else: grid_h_input += ch

    clock.tick(FPS)

# auto-save on exit
try:
    save_map()
    save_settings()
except Exception:
    pass

pygame.quit()
sys.exit()
