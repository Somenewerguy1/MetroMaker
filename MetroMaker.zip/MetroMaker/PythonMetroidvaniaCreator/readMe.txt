Metromaker is a tool (partially) by Somenewerguy 

ChatGPT 5 was used to aid in the process of building this tool.

Font Press Start 2P by Codeman38:

	“Press Start 2P” font by Codeman38, licensed under the SIL Open Font License (OFL).
	 https://fonts.google.com/specimen/Press+Start+2P


How to use:



	Put assets such as tiles in assets folder as .png files.
	Put fonts in the fonts folder as .ttf files.
	No need to touch the Icon folder but feel free if you want to.


Feel free to use, redistribute or do whatever with this small program and whatever you make with it. 

Enjoy!

:D